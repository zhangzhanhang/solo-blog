title: Nginx之限速防止流量攻击
date: '2019-04-28 22:16:29'
updated: '2019-04-28 22:18:01'
tags: [Nginx]
permalink: /articles/2019/04/28/1556460988943.html
---
使用场景
----

最近，报告查询系统负载均衡集群相关配置已经完成，两种实现方式分别是基于Ehcache和Redis的session管理策略。

大家都知道服务器资源有限的，但是客户端来的请求是无限的(不排除恶意攻击)， 为了保证大部分的请求能够正常响应，不得不放弃一些客户端来的请求，所以我们会采用Nginx的限流操作， 这种操作可以很大程度上缓解服务器的压力， 使其他正常的请求能够得到正常响应。

如何使用Nginx实现基本的限流，比如单个IP限制每秒访问50次。通过Nginx限流模块，我们可以设置一旦并发连接数超过我们的设置，将返回503错误给客户端。这样可以非常有效的防止CC攻击。再配合 iptables防火墙，基本上CC攻击就可以无视了。  

如何使用
----

### conf配置
```
#统一在http域中进行配置

#限制请求
limit_req_zone $binary_remote_addr $uri zone=api_read:20m rate=50r/s;
#按ip配置一个连接 zone
limit_conn_zone $binary_remote_addr zone=perip_conn:10m;
#按server配置一个连接 zone
limit_conn_zone $server_name zone=perserver_conn:100m;
server {
        listen       80;
        server_name  report.52itstyle.com;
        index login.jsp;
        location / {
              #请求限流排队通过 burst默认是0
              limit_req zone=api_read burst=5;
              #连接数限制,每个IP并发请求为2
              limit_conn perip_conn 2;
              #服务所限制的连接数(即限制了该server并发连接数量)
              limit_conn perserver_conn 1000;
              #连接限速
              limit_rate 100k;
              proxy_pass      http://report;
        }
}
upstream report {
        fair;
        server  172.16.1.120:8882 weight=1  max_fails=2 fail_timeout=30s;
        server  172.16.1.120:8881 weight=1  max_fails=2 fail_timeout=30s;
}
```
### 配置503错误

默认情况，超出限制额度，将会报503错误，提示：
```
503 Service Temporarily Unavailable The server is temporarily unable to service your request due to maintenance downtime or capacity problems. Please try again later. Sorry for the inconvenience. Please report this message and include the following information to us. Thank you very much!
```
这样显示没毛病，但是不够友好，这里我们自定义503错误。
```
error_page  500  502  503  504 /50x.html; location = /50x.html { root html;#自定义50X错误 }
```
配置说明
----

limit_conn_zone

是针对每个IP定义一个存储session状态的容器。这个示例中定义了一个100m的容器，按照32bytes/session，可以处理3200000个session。

limit_rate 300k;

对每个连接限速300k. 注意，这里是对连接限速，而不是对IP限速。如果一个IP允许两个并发连接，那么这个IP就是限速limit_rate×2。

burst=5；

这相当于在检查站req旁边放5个座位。如果某个请求当时超过速度限制被拦了，请他在空座位上坐着，等排队，如果检查站空了，就可以通过。如果连座位都坐满了，那就抱歉了，请求直接退回，客户端得到一个服务器忙的响应。所以说burst跟request_rate一点关系都没有，设成10000，就是1万个请求可以等着排队，而检查站还是1秒钟放行5个请求（龟速）。而且也不能一直排队，所以nginx还设了超时，排队超过一定时间，也是直接退回，返回服务器忙的响应。

以上配置Nginx需要配置以下模块：  
ngx_http_limit_conn_module (static)  
ngx_http_limit_req_module (static)

执行命令 nginx -V 就可以检查到是否有安装。

小结
--

限流的目的就是防止恶意请求流量，恶意哦公积，或者防止流量超出系统峰值。

实现方案有很多，Nginx的limit模块只是其中一个思路。对于恶意请求流量，限制访问到cache层或者对于恶意ip使用nginx deny进行屏蔽。