title: Nginx之负载均衡
date: '2019-04-28 22:22:00'
updated: '2019-04-28 22:22:00'
tags: [Nginx]
permalink: /articles/2019/04/28/1556461320345.html
---
负载均衡
----

负载均衡 建立在现有网络结构之上，它提供了一种廉价有效透明的方法扩展网络设备和服务器的带宽、增加吞吐量、加强网络数据处理能力、提高网络的灵活性和可用性。

负载均衡，英文名称为Load Balance，其意思就是分摊到多个操作单元上进行执行，例如Web服务器、FTP服务器、企业关键应用服务器和其它关键任务服务器等，从而共同完成工作任务。

架构图
---
![Nginxè´è½½åè¡¡.png](https://blog.52itstyle.vip/usr/uploads/2017/04/934640577.png)
负载均衡策略
------

Nginx 提供轮询（round robin）、IP 哈希（client IP）和加权轮询 3 种方式，默认情况下，Nginx 采用的是轮询。

### 轮询（默认）

每个请求按时间顺序逐一分配到不同的后端服务器，如果后端服务器down掉，能自动剔除。
```
upstream backserver { server  192.168.1.14; server  192.168.1.15; }
```
### 加权轮询

指定轮询几率，weight和访问比率成正比，用于后端服务器性能不均的情况。
```
upstream backserver { server  192.168.1.14 weight=1; server  192.168.1.15 weight=2; }
```
### ip_hash

每个请求按访问ip的hash结果分配，这样每个访客固定访问一个后端服务器，可以解决session的问题。
```
upstream backserver { ip_hash; server 192.168.0.14; server 192.168.0.15; }
```
重试策略
----

可以为每个 backserver 指定最大的重试次数，和重试时间间隔,所使用的关键字是 max_fails 和 fail_timeout。
```
upstream backserver { 
server  192.168.1.14 weight=1 max_fails=2 fail_timeout=30s; 
server  192.168.1.15 weight=2 max_fails=2 fail_timeout=30s; }
```
失败重试次数为3，且超时时间为30秒。
### 热机策略
```
upstream backserver { 
server  192.168.1.14 weight=1 max_fails=2 fail_timeout=30s; 
server  192.168.1.15 weight=2 max_fails=2 fail_timeout=30s; server  192.168.1.16 backup; }
```
当所有的非备机（non-backup）都宕机（down）或者繁忙（busy）的时候，就会使用由 backup 标注的备机。必须要注意的是，backup 不能和 ip_hash 关键字一起使用。
