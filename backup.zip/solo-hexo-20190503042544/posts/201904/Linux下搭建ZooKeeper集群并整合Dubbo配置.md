title: Linux下搭建ZooKeeper集群并整合Dubbo配置
date: '2019-04-28 22:06:15'
updated: '2019-04-28 22:06:15'
tags: [ZooKeeper, Dubbo]
permalink: /articles/2019/04/28/1556460375621.html
---
### 1.环境说明

Zookeeper 不仅可以单机提供服务,同时也支持多机组成集群来提供服务,实际上Zookeeper还支持另外一种伪集群的方式,也就是可以在一台物理机上运行多个Zookeeper实例.

Zookeeper通过复制来实现高可用性,只要集合体中半数以上的机器处于可用状态,它就能够保证服务继续。

因为官网建议至少3个节点，3台机器只要有2台可用就可以选出leader并且对外提供服务(2n+1台机器,可以容n台机器挂掉)。如果你仅仅安装了两台跟一台有什么区别？

这里我们在三台装有centos6.4（64位）的服务器上安装ZooKeeper。  

### 2.安装ZooKeeper

1）下载ZooKeeper，建议选择稳定版，即stable的。

wget [http://apache.dataguru.cn/zookeeper/stable/zookeeper-3.4.9.tar.gz](http://apache.dataguru.cn/zookeeper/stable/zookeeper-3.4.9.tar.gz)

2）解压 tar -xvf zookeeper-3.4.9.tar.gz

3）新建zoo.cfg并修改
```
# The number of milliseconds of each tick

tickTime=2000
# The number of ticks that the initial
# synchronization phase can take
initLimit=10
# The number of ticks that can pass between
# sending a request and getting an acknowledgement
syncLimit=5
# the directory where the snapshot is stored.
# do not use /tmp for storage, /tmp here is just
# example sakes.
dataDir=/tmp/zookeeper
# the port at which the clients will connect
clientPort=2181
# the maximum number of client connections.
# increase this if you need to handle more clients
#maxClientCnxns=60
#
# Be sure to read the maintenance section of the
# administrator guide before turning on autopurge.
#
# http://zookeeper.apache.org/doc/current/zookeeperAdmin.html#sc_maintenance
#
# The number of snapshots to retain in dataDir
#autopurge.snapRetainCount=3
# Purge task interval in hours
# Set to "0" to disable auto purge feature
#autopurge.purgeInterval=1
server.12=172.16.1.12:2888:3888
server.13=172.16.1.13:2888:3888
server.14=172.16.1.14:2888:3888
```
参数说明：   
①tickTime：心跳时间，毫秒为单位。

②initLimit：这个配置项是用来配置 Zookeeper 接受客户端（这里所说的客户端不是用户连接 Zookeeper服务器的客户端，而是 Zookeeper 服务器集群中连接到 Leader 的 Follower 服务器）初始化连接时最长能忍受多少个心跳时间间隔数。当已经超过 10 个心跳的时间（也就是 tickTime）长度后 Zookeeper 服务器还没有收到客户端的返回信息，那么表明这个客户端连接失败。总的时间长度就是 10*2000=20 秒。

③syncLimit：这个配置项标识 Leader 与 Follower 之间发送消息，请求和应答时间长度，最长不能超过多少个 tickTime 的时间长度，总的时间长度就是 5*2000=10 秒。

④dataDir：存储内存中数据库快照的位置。

⑤clientPort：监听客户端连接的端口

⑥server.A=B：C：D：其中 A 是一个数字，表示这个是第几号服务器；B 是这个服务器的 ip 地址；C 表示的是这个服务器与集群中的 Leader 服务器交换信息的端口；D 表示的是万一集群中的 Leader 服务器挂了，需要一个端口来重新进行选举，选出一个新的 Leader，而这个端口就是用来执行选举时服务器相互通信的端口。如果是伪集群的配置方式，由于 B 都是一样，所以不同的 Zookeeper 实例通信端口号不能一样，所以要给它们分配不同的端口号。

4）dataDir目录下创建myid文件，将内容设置为上⑥中的A值，用来标识不同的服务器。

### 3.同步复制到其他服务器

### 4.测试ZooKeeper

1）各节点上启动 zkServer.sh start  
2) 各节点查看状态 zkServer.sh status
```
JMX enabled by default Using config: /home/zookeeper-3.4.9/bin/../conf/zoo.cfg Mode: follower
```
注：如果状态 是Mode: follower 或者 Mode: leader 说明集群成功。

可能出现的问题：  
1）Error contacting service. It is probably not running.  
无法启动的问题，使用zkServer.sh start-foreground启动查看日志。

2）报错/tmp/zookeeper/myid file is missing  
原因：zk集群中的节点需要获取myid文件内容来标识该节点，缺失则无法启动；

解决方法：在zk数据文件存放目录下（见 $ZK/conf/zoo.cfg，dataDir属性），创建myid文件并写入一个数字用来标识本节点（类似这个节点的身份证）。

三台机器分别执行：  
echo '12' > /tmp/zookeeper/myid  
echo '13' > /tmp/zookeeper/myid  
echo '14' > /tmp/zookeeper/myid

由于配置在tmp目录，重启机器可能会丢失。

2）其中一台zookeeper是单例状态 Mode: standalone ，重启下服务试试。

### 5.ZooKeeper集群整合Dubbo配置

Zookeeper单机配置：  
方式一、
```
<dubbo:registry  address="zookeeper://10.20.153.10:2181"/>
```
方式二、
```
<dubbo:registry  protocol="zookeeper"  address="10.20.153.10:2181"/>
```
Zookeeper集群配置:
方式一、
```
<dubbo:registry  address="zookeeper://10.20.153.10:2181?backup=10.20.153.11:2181,10.20.153.12:2181"/>
```
方式二、
```
<dubbo:registry  protocol="zookeeper"  address="10.20.153.10:2181,10.20.153.11:2181,10.20.153.12/>
```
集群配置方式一，特别适用于dubbo-admin 和dubbo-monitor