title: SpringBoot整合OAuth2保证api接口安全
date: '2019-04-28 15:14:28'
updated: '2019-04-28 15:15:29'
tags: [SpringBoot]
permalink: /articles/2019/04/28/1556435668557.html
---
![](https://img.hacpai.com/bing/20181127.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

1、 OAuth 概念
    OAuth 是一个开放标准，允许用户让第三方应用访问该用户在某一网站上存储的私密的资源（如照片，视频，联系人列表），而不需要将用户名和密码提供给第三方应用。OAuth允许用户提供一个令牌，而不是用户名和密码来访问他们存放在特定服务提供者的数据。每一个令牌授权一个特定的网站在特定的时段内访问特定的资源。这样，OAuth让用户可以授权第三方网站访问他们存储在另外服务提供者的某些特定信息，而非所有内容。
2、OAuth 2.0 认证流程

第一步：得到授权码 code

首先直接跳转至用户授权地址，即图示 Request User Url ，提示用户进行登录，并给予相关资源授权，得到唯一的 Auth code ，这里注意的是 code 只有 10 分钟的有效期，对于安全考虑，相对于 OAuth 1.0 省了一步获取临时的 Token ，并且有效期也进行了控制，比 1.0 认证简化了很多，并安全一些；

第二步：获取 access token

得到授权 code 后，就是请求 access token ，通过图示 Request access url ，生成得到数据 Token ；

第三步：通过 access token, 获取 OpenID

通过 Access Token 请求 OpenID ， OpenID 是用户在此平台的唯一标识，通过图示 Request info url 请求，然后得到 OpenID ；

第四步：通过 access token 及 OpenID 调用 API,获取用户授权信息

通过第二步得到的数据 Token 、第三步得到的 OpenID 及相关 API ，进行请求，获取用户授权资源信息。

3、OAuth 授权模式

OAuth2.0 定义了 四种授权模式。分别为：

授权码模式
简化模式
密码模式
客户端模式
4、oauth2 实例

可以分为简易的分为三个步骤

配置资源服务器
配置认证服务器
配置spring security

4.1、构建工程
![è¿éåå¾çæè¿°](https://img-blog.csdn.net/20180525232756825?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2xpdXdlaWxvbmcwNw==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)
pom文件添加oauth2依赖
```
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-security</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.security.oauth</groupId>
    <artifactId>spring-security-oauth2</artifactId>
</dependency>
```
4.2、配置资源服务器

@EnableResourceServer注解来开启资源服务器
```
package com.vesus.springbootoauth2.config;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;

@Configuration
@EnableResourceServer
public class ResourceServerConfiguration extends ResourceServerConfigurerAdapter {

    private Logger logger = LoggerFactory.getLogger(ResourceServerConfiguration.class);

    @Autowired
    private CustomAuthenticationEntryPoint customAuthenticationEntryPoint ;

    @Bean
    public CustomLogoutSuccessHandler customLogoutSuccessHandler(){
        return new CustomLogoutSuccessHandler();
    } ;

    @Override
    public void configure(HttpSecurity http) throws Exception {
        logger.info("=========================111111111=========");
       http.exceptionHandling()
               .authenticationEntryPoint(customAuthenticationEntryPoint)
               .and()
               .logout()
               .logoutUrl("/oauth/logout")
               .logoutSuccessHandler(customLogoutSuccessHandler())
               .and()
               .authorizeRequests()
               .antMatchers("/hello/").permitAll()
               .antMatchers("/secure/**").authenticated();
    }
}
```
4.3、自定义401错误码内容
package com.vesus.springbootoauth2.config;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component
public class CustomAuthenticationEntryPoint implements AuthenticationEntryPoint {

    private final Logger log = LoggerFactory.getLogger(CustomAuthenticationEntryPoint.class);


    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException) throws IOException, ServletException {
        log.info("Pre-authenticated entry point called. Rejecting access");
        response.sendError(HttpServletResponse.SC_UNAUTHORIZED,"Access Denied");
    }
}
4.4、定义登出控制

退出系统时需要访问SpringSecrutiy的logout方法来清空对应的token信息



































```
package com.vesus.springbootoauth2.config;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.web.authentication.AbstractAuthenticationTargetUrlRequestHandler;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class CustomLogoutSuccessHandler extends AbstractAuthenticationTargetUrlRequestHandler implements LogoutSuccessHandler {

    private static final String BEARER_AUTHENTICATION = "Bearer ";
    private static final String HEADER_AUTHORIZATION = "authorization";

    @Autowired
    private TokenStore tokenStore ;

    @Override
    public void onLogoutSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
        String token = request.getHeader(HEADER_AUTHORIZATION);
        if (token!=null&&token.startsWith(BEARER_AUTHENTICATION)){
            OAuth2AccessToken oAuth2AccessToken = tokenStore.readAccessToken(token.split(" ")[0]);
            if (oAuth2AccessToken!=null){
                tokenStore.removeAccessToken(oAuth2AccessToken);
            }
        }

        response.setStatus(HttpServletResponse.SC_OK);
    }
}
```
4.6、安全配置
```
package com.vesus.springbootoauth2.config;


import com.vesus.springbootoauth2.service.impl.CustomUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.method.configuration.GlobalMethodSecurityConfiguration;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.oauth2.provider.expression.OAuth2MethodSecurityExpressionHandler;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    @Bean
    UserDetailsService customUserService(){
        return new CustomUserService();
    }

    //配置全局设置
    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        //设置UserDetailsService以及密码规则
        auth.userDetailsService(customUserService());
    }

    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring().antMatchers("/hello") ;
    }

    @Bean
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean() ;
    }

    //开启全局方法拦截
    @EnableGlobalMethodSecurity(prePostEnabled = true, jsr250Enabled = true)
    public static class GlobalSecurityConfiguration extends GlobalMethodSecurityConfiguration {
        @Override
        protected MethodSecurityExpressionHandler createExpressionHandler() {
            return new OAuth2MethodSecurityExpressionHandler();
        }

    }
}
```
4.7、启动

访问localhost:8080/hello
```
hello
```
使用postman访问localhost:8080/oauth/token?username=admin&password=admin&grant_type=password
![è¿éåå¾çæè¿°](https://img-blog.csdn.net/20180525232821858?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2xpdXdlaWxvbmcwNw==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)
```
{

    "access_token": "acf03e60-ed0a-4809-9ee0-240b81aab2d1",
    "token_type": "bearer",
    "refresh_token": "5b4a562e-704d-442a-9dfe-4aebad930e9d",
    "expires_in": 1799,
    "scope": "read write"
}
```
访问：[http://127.0.0.1:8080/login?access_token=b39c8a28-18fb-4d79-93e6-40f7203b8049](http://127.0.0.1:8080/login?access_token=b39c8a28-18fb-4d79-93e6-40f7203b8049)
```
login
```
源码：[https://gitee.com/vesus198/springboot-demo/tree/master/springboot-oauth2](https://gitee.com/vesus198/springboot-demo/tree/master/springboot-oauth2)